function converte(){

    

    fah = (v1-32)*(5/9);


    document.write("A temperatura em que convertemos para graus Celsius, ficou com o valor de " + fah);
}
